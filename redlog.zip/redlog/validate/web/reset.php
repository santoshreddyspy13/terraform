<?php    
    
 include("../../dbconn/dbconn.php");//make connection here

  if(isset($_POST['submit']))  
  { 
      $email=mysqli_real_escape_string($conn,$_POST['email']);//here getting result from the post array after submitting the form.  
     
      $check_email_query="SELECT * FROM `red` WHERE `email`=TRIM(LOWER('$email'))";  
      $run_query=mysqli_query($conn,$check_email_query);  
    
      if(mysqli_num_rows($run_query)==0)  
      {  
         ?> <script>
         alert('Email does not exist !') ;
          window.open('login.php','_self');</script>

         <?php
        

               exit();  
      }  
      else{
            if($_POST['perform'] == "PR"){
                      echo "<script> window.open('https://demo.mindtree-automation.com/resolve/service/execute?_username_=robo&_password_=Mind@123&ACTION=EXECUTEPROCESS&WIKI=poc.ApplicationPasswordReset&PROBLEMID=NEW&PERFORM=PR&EMAIL=$email','_blank');   window.open('login.php','_self');</script>";  
         /// header("Location: login.php"); 
            }else{
                  echo "<script> window.open('https://demo.mindtree-automation.com/resolve/service/execute?_username_=robo&_password_=Mind@123&ACTION=EXECUTEPROCESS&WIKI=poc.ApplicationPasswordReset&PROBLEMID=NEW&PERFORM=AU&EMAIL=$email','_blank');  window.open('login.php','_self');</script>";
            }
      }
}

      ?>