
<?php  
  
  include("../../dbconn/dbconn.php");//make connection here  
  if(isset($_POST['register']))  
  {   $full_name=mysqli_real_escape_string($conn,$_POST['full_name']);
      $email=mysqli_real_escape_string($conn,$_POST['email']);//here getting result from the post array after submitting the form.  
      $user_pass=mysqli_real_escape_string($conn,$_POST['pass']);//same  

    
    
      if($full_name=='')  
      {  
          //javascript use for input checking  
          echo"<script>alert('Please enter the name')</script>";  
  exit();//this use if first is not work then other will not show  
      }  
    
      if($email=='')  
      {  
          echo"<script>alert('Please enter the email')</script>";  
      exit();  
      }  
   
  //here query check weather if user already registered so can't register again.  
      $check_email_query="SELECT * FROM `red` WHERE `email`='$email'";  
      $run_query=mysqli_query($conn,$check_email_query);  
    
      if(mysqli_num_rows($run_query)>0)  
      {  
  echo "<script>alert('Email $email is already exist in our database, Please try another one!')</script>";  
  exit();  
      }  
  //insert the user into the database.  
      $insert_user="INSERT INTO `red`( `full_name`, `email`, `pass`) VALUES ('$full_name','$email','$user_pass')";  
      if(mysqli_query($conn,$insert_user))  
      {  echo"<script>alert('Registration Succesful !!!')</script>";
          echo"<script>window.open('register.php','_self')</script>";  
      }  
    
    
    
  }  
    
  ?>  