<?php

session_start();

//server workign
include '../../dbconn/dbconn.php';

if(isset($_POST['login'])){
    $email =$_POST['email'];
    $pass =$_POST['pass'];

    $sql= "SELECT * FROM `red` WHERE `email`= TRIM(LOWER('$email')) AND `pass`='$pass'  ";

    $query= mysqli_query($conn,$sql);

    $row= mysqli_num_rows($query);
    $data=mysqli_fetch_assoc($query);

        if($row==1 && $data['status']==1){
            echo "login successful";
            
            $id=$data['id'];
            $full_name=$data['full_name'];
            $_SESSION['uid']=$id;
            $_SESSION['email']=$email;
            $_SESSION['full_name']=$full_name;
            header('location:../../form.php');

        }

        else if( $row==1 && $data['status']==0){
            ?>
            <script>
                alert('Account is locked !!!');
                window.open('login.php','_self');
         </script>
            
            <?php

        }


        else {
           ?>
           <script>
               alert('Username and Password is incorrect !!!');
               window.open('login.php','_self');
        </script>
           
           <?php
        }


    }

?>