<?php
$servername="localhost";
$username="root";
$password="Test123";
$db="redlog";

$conn=mysqli_connect("$servername","$username","$password","$db");
if($conn==TRUE)
{
    // echo"connection success";
}
else{

    echo mysqli_error($conn);
}


?>